//
//  linageApp.swift
//  linage
//
//  Created by Martin on 05/04/2022.
//

import SwiftUI

@main
struct linageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
