/*
  Warnings:

  - You are about to drop the column `qrCode` on the `Ticket` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Ticket" DROP COLUMN "qrCode",
ADD COLUMN     "tid" TEXT;
